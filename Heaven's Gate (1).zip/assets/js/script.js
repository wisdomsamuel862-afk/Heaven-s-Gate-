const form = document.getElementById("form");
const age = document.getElementById("age");
const success = document.getElementById("successMsg");
const fail = document.getElementById("failMsg");

form.addEventListener("submit", function(event){
  event.preventDefault();
});

age.addEventListener("input", function(event){
  const typed = parseInt(event.target.value); // ✅ use event.target.value
  // OR you can use: parseInt(age.value)

  console.log(typed); // open console to see if you get number

  if (typed >= 5 && typed <= 18) {
    success.textContent = "Your Child is now our Student";
    fail.textContent = "";
  } else if (typed >= 19) {
    fail.textContent = "Your Child is too Old to be our student";
    success.textContent = "";
  } else if (typed > 0 && typed < 5) {
    fail.textContent = "Your Child is too Young";
    success.textContent = "";
  } else {
    success.textContent = "";
    fail.textContent = "";
  }
}); 